$(function() {
    // build array of all views
    let views = [];
    let viewsSettings = {
        type: 'GET',
        url: '/api/v2/views.json?page[size]=100',
        data: 'query=active:true',
        dataType: 'json'
    }
    return getViews(views, viewsSettings);
})

function getViews(views, viewsSettings) {
    console.log('getViews()');
    // console.log('getViews():', '\nviews: ', views, '\nviewsSettings: ', viewsSettings);
    let client = ZAFClient.init(); // interacts with Zendesk API
    // async required
    return client.request(viewsSettings).then((viewsResponse) => {
        views = views.concat(viewsResponse['views']);
        if (viewsResponse['meta']['has_more']) {
            viewsSettings['url'] = viewsResponse['links']['next'];
            return getViews(views, viewsSettings);
        } else {
            // console.log('Views [END]: ', views);
            let groups = [];
            let groupsSettings = {
                type: 'GET',
                url: '/api/v2/groups.json?page[size]=100'
            }
            return getGroups(groups, groupsSettings, views);
        }
    })
}

function getGroups(groups, groupsSettings, views) {
    console.log('getGroups');
    let client = ZAFClient.init();
    // async required
    return client.request(groupsSettings).then((groupsResponse) => {
        // console.log(groupsResponse);
        groups = groups.concat(groupsResponse['groups']);
        if (groupsResponse['meta']['has_more']) {
            groupsSettings['url'] = groupsResponse['links']['next'];
            return getGroups(groups, groupsSettings, views);
        } else {
            // console.log('Groups [END]: ', groups);
            let client = ZAFClient.init();
            return client.get('currentUser').then((response) => {
                let userGroups = response['currentUser']['groups'];
                let userGroupsIDs = [];
                for (let u of userGroups) {
                    userGroupsIDs.push(u['id']);
                }
                for (let g of groups) {
                    if (userGroupsIDs.includes(g['id'])) {
                        g['member'] = true;
                    } else {
                        g['member'] = false;
                    }
                }
                return addViewsToGroups(groups, views);
            })
        }
    })
}

function addViewsToGroups(groups, views) {
    console.log('addViewsToGroups()');
    for (let g of groups) {
        g['views'] = [];
        for (let v of views) {
            if (v['conditions']['all'].length > 0) {
                for (let c_all of v['conditions']['all']) {
                    if (c_all['field'] == 'group_id' && c_all['operator'] == 'is' && c_all['value'] == g['id']) {
                        g['views'].push(v);
                    } 
                }
            }
            if (v['conditions']['any'].length > 0) {
                for (let c_any of v['conditions']['any']) {
                    if (c_any['field'] == 'group_id' && c_any['operator'] == 'is' && c_any['value'] == g['id']) {
                        g['views'].push(v);
                    }
                }
            }
        }
    }
    // console.log('addViewsToGroups [END]:', '\nGroups: ', groups);
    return addGroupsViews(groups);
}

function addGroupsViews(groups) {
    console.log('addGroupsViews()');
    for (let g of groups) {
        let groupViewsSettings = {
            url: '/api/v2/views/search.json',
            type: 'GET',
            data: `query=group_id:${g['id']}&active:true`,
            dataType: 'json'
        }
        getGroupViews(g, groupViewsSettings);
    }
    let personalViews = [];
    let personalViewsSettings = {
        url: '/api/v2/views/compact.json',
        type: 'GET'
    };
    return addPersonalViews(groups, personalViews, personalViewsSettings);
}

function getGroupViews(g, groupViewsSettings) {
    console.log('getGroups()');
    let client = ZAFClient.init();
    groupViewsSettings['data'] = `query=group_id:${g['id']}&active=true`;
    return client.request(groupViewsSettings).then((response) => {
        for (let v of response['views']) {
            g['views'].push(v);
        }
        if (response['next_page']) {
            groupViewsSettings['url'] = response['next_page'];
            return getGroupViews(g, groupViewsSettings);
        } else {
            return;
        }
    })
}

function addPersonalViews(groups, personalViews, personalViewsSettings) {
    console.log('addpersonalViews()');
    let client = ZAFClient.init();
    return client.request(personalViewsSettings).then((response) => {
        console.log('Personal Views response: ', response);
        for (let v of response['views']) {
            if (v['restriction']){
                if (v['restriction']['type'] == 'User') {
                    personalViews.push(v);
                }
            }
        }
        groups = cleanupGroups(groups);
        return buildTable(groups, personalViews);
    })
}

function cleanupGroups(groups) {
    for (let g of groups) {
        for (let v of g['views']) {
            let id = v['id'];
            let arr = [];
            for (let v2 of g['views']) {
                if (v['id'] == v2['id']){
                    arr.push(v2);
                }
            }
            if (arr.length > 1) {
                g['views'].splice(g['views'].indexOf(v), 1);
                console.log('Removed duplicate view from ', g['name']);
            }
        }
    }
    return groups;
}

function buildTable(groups, personalViews) {
    console.log('buildTable()');
    Handlebars.registerHelper('json', function(context) {
        return JSON.stringify(context);
    });
    let blob = {'groups': groups, 'personalViews': personalViews};
    let source = $('#template').html();  
    let template = Handlebars.compile(source);
    let html = template(blob);
    $('#content').html(html);
}

function showViews(views){
    // console.log('showViews():', views);
    let td = ['<tr><td class="cell" onclick="linkTo(', ')" >', '</td></tr>']
    let elem = document.getElementById('viewsTable');
    // console.log('elem: ', elem);
    let html = `<table id="viewsTable"><th>Views</th>`;
    if (views.length > 0) {
        for (let v of views) {
            html += `${td[0]}${v['id']}${td[1]}${v['title']}${td[2]}`
        }
    } else {
        html += `<tr><td id="tooltip" class="cell"><span id="tooltipText">!---No views for selected group---!</span></td></tr>`
    }
    html += '</table>'
    // console.log('html: ', html);
    elem.innerHTML = html;
    return;
}

function linkTo(viewID) {
    // console.log('linkTo(): ', viewID)
    let client = ZAFClient.init();
    client.invoke('routeTo', 'views', viewID);
    return;
}